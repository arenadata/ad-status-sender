#!/bin/bash
#This script will perform changes of MTU and buffer's sizes on your hosts.
#The first part of this script rewriting rmem and wmem parameters. Its necessary for increase network buffers's sizes.
#The second part - MTU define the Maximum Transmission Unit size. For proper working ADB we need to set maximum numder.
#This number depends from cloud provider's network posibilities and usualy is approximately 8800 bytes

set -e
FILE=/etc/sysctl.conf
if [ -f "$FILE" ]; then
    sed -i '/net.core.rmem_max=[0-9]*/d' $FILE
    sed -i '/net.core.rmem_default=[0-9]*/d' $FILE
    sed -i '/net.core.wmem_max=[0-9]*/d' $FILE
    sed -i '/net.core.wmem_default=[0-9]*/d' $FILE

    echo "net.core.rmem_max=26214400" >> $FILE
    echo "net.core.rmem_default=26214400" >> $FILE
    echo "net.core.wmem_max=26214400" >> $FILE
    echo "net.core.wmem_default=26214400" >> $FILE

  else
    echo "net.core.rmem_max=26214400" >> $FILE
    echo "net.core.rmem_default=26214400" >> $FILE
    echo "net.core.wmem_max=26214400" >> $FILE
    echo "net.core.wmem_default=26214400" >> $FILE
fi
sysctl -p $FILE
DEV=$(sudo lshw -class network | grep -A 1 "bus info" | grep name | awk -F': ' '{print $2}')
args=()

for i in $DEV; do
    args+=("/etc/sysconfig/network-scripts/ifcfg-$i")
    devs+=("$i")
done

arrlen=${#args[@]}
if [ $arrlen == 1 ]; then
    find /etc/sysconfig/network-scripts/ -name "ifcfg-*" -and -not -path "/etc/sysconfig/network-scripts/ifcfg-$DEV" -delete
    ip link set mtu 8800 dev $DEV
    echo "MTU="8800"" >> ${args[0]}
    systemctl restart network.service
  else
    files_array=(/etc/sysconfig/network-scripts/ifcfg-*)
    files_to_delete=$(echo ${files_array[@]} ${args[@]} | tr ' ' '\n' | sort | uniq -u )
    unset 'devs[0]'
    for int in ${devs[@]}; do
      sudo ip link set mtu 8800 dev $int
      echo "MTU="8800"" >> /etc/sysconfig/network-scripts/ifcfg-$int
    done
    rm -f $files_to_delete
    systemctl restart network.service
fi

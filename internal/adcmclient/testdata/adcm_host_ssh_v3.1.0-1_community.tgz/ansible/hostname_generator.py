#!/usr/bin/env python3
import sys
import argparse


def count_num_len(
        mask: str,
) -> int:
    """
    Returns minimal hostname number length
    """
    return len(mask) - len(mask.replace('#', ''))


def insert_num(
        mask: str,
        number: int,
        num_len: int,
):
    """
    Replaces #s with number
    """
    # Split mask on parts
    mask_start = mask[:mask.find('#')]
    mask_end = mask[mask.rfind('#') + 1:]
    # Generate number with standard method
    number = str(number).zfill(num_len)
    return mask_start + number + mask_end


def generate_hostname(
        mask: str,
        number: int,
) -> str:
    """
    Generates hostname with number from mask
    """
    num_len = count_num_len(mask)
    return insert_num(mask, number, num_len)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Hostname generator')
    parser.add_argument('--mask', required=True, help='Base name from job.config.hostname_mask')
    parser.add_argument('--num', required=True, help='Number from item value in sequence')

    args = parser.parse_args()

    hostname = generate_hostname(args.mask, args.num)
    print(hostname)
    sys.exit(0)

#!/usr/bin/env python3
"""This script moves directories from vcloud module to ansible directory to store modules
"""

import shutil
from os.path import realpath, split, join

path, _ = split(realpath(__file__))

shutil.copytree(join(path, 'ansible/roles/'), join(path, 'ansible/common_data/playbooks/roles/'), dirs_exist_ok=True)

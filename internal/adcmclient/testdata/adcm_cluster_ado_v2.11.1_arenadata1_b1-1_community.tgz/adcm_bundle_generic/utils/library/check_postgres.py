#!/usr/bin/python
# -*- coding: utf-8 -*-
""" The module checks the user's rights to the database """

# pylint: disable=E0401, C0114, E0401, R0913
from ansible.module_utils.basic import AnsibleModule
import psycopg2
from psycopg2 import OperationalError, ProgrammingError


DOCUMENTATION = r'''
---
module: check_postgres
short_description: Check remote PostgreSQL server availability
description:
- Simple module to check remote PostgreSQL server availability.
options:
  host:
    description:
    - IP or server name
    type: str
  port:
    description:
    - The port on which the service is running
    type: int
  connect_timeout:
    description:
    - The port on which the service is running
    type: int
  user:
    description:
    - Database User
    type: str
  password:
    description:
    - password of the database user
    type: str
  dbname:
    description:
    - Name of a database to connect to.
    type: str
  custom_sql_requests:
    description:
    - Name of a database to connect to.
    type: list
'''

EXAMPLES = r'''
# PostgreSQL ping dbsrv server from the shell:
# ansible dbsrv -m postgresql_ping
# In the example below you need to generate certificates previously.
# See https://www.postgresql.org/docs/current/libpq-ssl.html
# for more information.
- name: Check postgres DB
  check_postgres:
    host: string
    port: int
    user: string
    password: string
    dbname: string
    custom_sql_requests: list
  register: result
  # If you need to fail when the server is not available,
  # uncomment the following line:
  #failed_when: not result.is_available
# You can use the registered result with another task
- name: This task should be executed only if the server is available
  # ...
  when: result.is_available == true
'''

RETURN = r'''
is_available:
  description: PostgreSQL server availability.
  returned: always
  type: bool
  sample: true
msg:
  description: sql request --> statusmessage.
  returned: always
  type: list
  sample: true
'''


def check_connected(module, host, port, connect_timeout, user,
                    password, dbname, custom_sql_requests):
    '''connect run test queries confirming the possibility
    of interacting with the database'''
    # pylint: disable=C0209,R0913
    tested_sql_select = [
        'SELECT 1;',
        'CREATE TABLE {0}_{1}_test_table ( {0}_test_column INT)'.format(
            dbname, user),
        'INSERT INTO {0}_{1}_test_table VALUES (1)'.format(dbname, user),
        'DELETE FROM {0}_{1}_test_table WHERE {0}_test_column=1'.format(
            dbname, user),
        'DROP TABLE {0}_{1}_test_table'.format(dbname, user)
    ]
    tested_sql_select.extend(custom_sql_requests)
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            connect_timeout=connect_timeout,
            user=user,
            password=password,
            dbname=dbname
        )
    except OperationalError as err:
        module.fail_json(msg='Unable to connect! {0}'.format(
            err), is_available=False)

    cursor = conn.cursor()
    sql_result = []
    for select in tested_sql_select:
        try:
            cursor.execute(select)
            sql_result.append(
                '{0} -->> {1}'.format(select, cursor.statusmessage))
        except ProgrammingError as err:
            module.fail_json(
                msg='{0} -->> {1}'.format(select, err), is_available=False)

    conn.close()
    module.exit_json(changed=True, msg='\n'.join(sql_result),
                     is_available=True)


def main():
    '''main'''
    # pylint: disable=R1735
    module = AnsibleModule(
        argument_spec=dict(
            host=dict(required=True),
            port=dict(required=False, type='int', default=5432),
            connect_timeout=dict(required=False, type='int', default=10),
            user=dict(required=True),
            password=dict(required=True, no_log=True),
            dbname=dict(required=True),
            custom_sql_requests=dict(required=False, type='list', default=[])
        ),
        supports_check_mode=True
    )

    if module.check_mode:
        module.exit_json(changed=False)

    host = module.params['host']
    port = module.params['port']
    connect_timeout = module.params['connect_timeout']
    user = module.params['user']
    password = module.params['password']
    dbname = module.params['dbname']
    custom_sql_requests = module.params['custom_sql_requests']

    check_connected(
        module, host, port, connect_timeout, user, password,
        dbname, custom_sql_requests
    )


if __name__ == '__main__':
    main()

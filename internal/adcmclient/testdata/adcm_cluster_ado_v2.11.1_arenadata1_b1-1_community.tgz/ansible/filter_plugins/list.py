'''Custom ansible filters for lists'''

# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance
# pylint: disable=W0108, unnecessary-lambda


class FilterModule(object):

    def filters(self):
        return {
            'sort_by_list': self.sort_by_list
        }

    def sort_by_list(self, list_to_sort, list_of_order):
        '''Sorts list by another list'''
        return sorted(list_to_sort, key=lambda x: list_of_order.index(x))

# pylint: disable=R0205, useless-object-inheritance
# pylint: disable=W1401, anomalous-backslash-in-string
# pylint: disable=C0209, consider-using-f-string

"""
This module provides a filter for escaping special characters in organizational unit (OU)
strings within a given input string.

Functions:
    escape_ou(input_str: str) -> str
        Escapes special characters in OU strings found within the input string.
"""
import re


SPECIAL_CHARS = r'\"#,;<=>'
PREFIXES = ['DC', 'CN', 'OU', 'O', 'STREET', 'L', 'ST', 'C', 'UID']


def escape_ou(input_str):
    prefix_pattern = "|".join(PREFIXES)
    ou_pattern = rf'({prefix_pattern})=(.*?)(?=,({prefix_pattern})=|$)'

    def escape_special_chars(match):
        value = match.group(2)
        for symbol in SPECIAL_CHARS:
            value = value.replace(symbol, f'\\{symbol}')
        return f'{match.group(1)}={value}'

    escaped_str = re.sub(ou_pattern, escape_special_chars, input_str)

    return escaped_str


class FilterModule(object):
    def filters(self):
        return {"escape_ou": escape_ou}

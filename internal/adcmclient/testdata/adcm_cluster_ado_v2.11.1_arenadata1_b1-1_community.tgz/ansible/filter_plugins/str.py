'''Custom ansible filters for strings'''

# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance
# pylint: disable=W0108, unnecessary-lambda


class FilterModule(object):

    def filters(self):
        return {
            'split_append_join': self.split_append_join,
            'split_prepend_join': self.split_prepend_join,
            'add_trailing_slash': self.add_trailing_slash,
            'remove_trailing_slash': self.remove_trailing_slash,
        }

    def split_append_join(self, s, d, a):  # pylint: disable = invalid-name
        '''
        Intended to replace following ansible equivalent:
        s.split(d) | map('regex_replace', '(.*)', '\\1' ~ a) | join(d)
        Example:
        'host1:host2' | split_append_join(':', '[0:]') -> 'host1[0:]:host2[0:]'
        '''
        return d.join([i + a for i in s.split(d)])

    def split_prepend_join(self, s, d, p):  # pylint: disable = invalid-name
        '''
        Equal with split_prepend_join except string prepends to every splitted item.
        'host1,host2' | split_prepend_join(',', 'http://') -> 'http://host1,http://host2'
        '''
        return d.join([p + i for i in s.split(d)])

    def add_trailing_slash(self, s):  # pylint: disable = invalid-name
        '''
        For cases sensitive to presence of trailing slash
        '''
        return s if s.endswith('/') else s + '/'

    def remove_trailing_slash(self, s):  # pylint: disable = invalid-name
        '''
        For cases sensitive to absence of trailing slash
        '''
        return s[:-1] if s.endswith('/') else s

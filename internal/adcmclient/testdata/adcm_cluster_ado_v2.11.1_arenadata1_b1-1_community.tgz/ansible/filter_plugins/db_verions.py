# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance

'''Custom ansible filters for check db version compatibility'''


class FilterModule(object):
    def filters(self):
        return {
            'check_db_version_compatibility': self.check_db_version_compatibility,
        }

    def check_db_version_compatibility(self, version, compatibility_versions):
        """
        Check if the version is compatible with the list of compatibility versions.

        :param version: The version string to be checked (e.g. "5.6.22").
        :type version: str or int
        :param compatibility_versions: A list of compatibility versions.
            Each item can either be a simple string (e.g. "11") or a dictionary
            (e.g. {"major": "5", "minor": "7"}).
        :type compatibility_versions: list
        :return: True if the version is compatible, False otherwise.
        :rtype: bool
        """
        if isinstance(version, int):
            version = str(version)
        if '.' in version:
            version_major, version_minor = version.split('.')[:2]
        else:
            version_major = version
            version_minor = None

        for c_v in compatibility_versions:
            if isinstance(c_v, dict):
                if c_v.get("major") == version_major:
                    if c_v.get("minor", None) is None or c_v.get("minor") == version_minor:
                        return True
            elif str(c_v) == version_major:
                return True
        return False

# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance

'''Custom ansible filter based on urllib.parse.quote_plus()'''
import urllib.parse


class FilterModule(object):
    def filters(self):
        return {
            'urllib_parse_quote_plus': self.urllib_parse_quote_plus,
        }

    def urllib_parse_quote_plus(self, text: str):
        '''
        Replace special characters in string using the %xx escape.
        Also it replaces '%' with '%%' in order to avoid configparser.InterpolationSyntaxError.
        '''

        return urllib.parse.quote_plus(text).replace('%', '%%')

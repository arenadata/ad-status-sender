# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance

'''Custom ansible filters for transforming URLs'''


from urllib.parse import urlparse


class FilterModule(object):
    def filters(self):
        return {
            'url_user_pass': self.url_user_pass,
        }

    def url_user_pass(self, url, username=None, password=None):
        '''Inserts username or username:password into URL'''
        url = url.strip()
        username = username.strip()
        password = password.strip()

        full_url = ""
        url_parsed = urlparse(url)
        url_scheme = url_parsed.scheme
        url_without_scheme = url.split('://')[-1]

        if url_scheme:
            full_url = url_scheme + "://"
        if username:
            if password:
                full_url += username + ":" + password + "@"
            else:
                full_url += username + "@"

        return full_url + url_without_scheme

# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance

'''Custom ansible filters for inventory'''


class FilterModule(object):

    def filters(self):
        return {
            'append_group_mark': self.append_group_mark,
            'get_components_from_inventory': self.get_components_from_inventory,
        }

    def append_group_mark(self, hosts):
        '''
        Intended to use in hosts of play to append a group mark [0:]
        if given hosts item is not explicitly a group:
        'group1.sub:group2.sub[0]' -> 'group1.sub[0:]:group2.sub[0]'
        '''
        hosts_slices = []
        in_brackets = False
        explicit_group = False
        for char in hosts:
            if char == '[':
                in_brackets = True
                explicit_group = True
            elif char == ']':
                in_brackets = False
            if char == ':':
                if in_brackets:
                    hosts_slices.append(':')
                else:
                    if explicit_group:
                        hosts_slices.append(':')
                    else:
                        hosts_slices.append('[0:]:')
                    explicit_group = False
            else:
                hosts_slices.append(char)
        if not explicit_group:
            hosts_slices.append('[0:]')
        return ''.join(hosts_slices)

    def get_components_from_inventory(self, group_var, service_name, components_filter=None):
        '''
        This filter has 2 distinctive use cases:
        1) get components on host from group_names var by provided service_name
        and optionally narrow it with specific components.
        It's designed to use in generic's playbook.yaml and the subtelty here is
        that this filter is in charge of whether specific component task would be
        applied to specific host.
        2) get all existing components from groups var by provided service_name
        and optionally narrow it with specific components.
        '''
        components = []
        for group in group_var:
            if group.startswith(service_name + '.'):
                component_split = group.split('.')
                if len(component_split) > 2:
                    continue
                component = component_split[1]
                if components_filter is not None and component not in components_filter:
                    continue
                components.append(component)
        if 'maintenance_mode' in components:
            components.remove('maintenance_mode')
        return components

# pylint: disable=C0111, missing-docstring
# pylint: disable=R0205, useless-object-inheritance

'''Custom ansible filters for dicts'''

import copy


class FilterModule(object):

    def filters(self):
        return {
            'del_by_list': self.del_by_list,
            'del_empty_keys': self.del_empty_keys,
            'deep_merge_dict': self.deep_merge_dict,
            'list_to_deep_merged_dict': self.list_to_deep_merged_dict

        }

    def del_by_list(self, dict_to_reduce, list_of_keys):
        '''Deletes items of dict by list of keys provided'''
        dict_to_return = copy.deepcopy(dict_to_reduce)
        for item in list_of_keys:
            if item in dict_to_return:
                del dict_to_return[item]
        return dict_to_return

    def del_empty_keys(self, dict_to_trim):
        '''Removes all keys with empty and undefined values'''
        dict_to_return = {
            k: v for k, v in dict_to_trim.items()
            if not (isinstance(v, str) and v.strip() == '') and v not in [None, {}, []]
        }
        return dict_to_return

    def deep_merge_dict(self, dict_to_iterate, dict_to_update):
        '''
        Deep merge two dicts. In particular left merge.
        This not the same as {**dict_to_iterate, **dict_dict_to_update}. For example:
        input dict_to_iterate = {
            "key1": {"inner_key1": "value1"},
            "key3": {"inner_key3": "value3"}
        }
        input dict_to_update = {
            "key1": {"inner_key1: "value0"}
            "key1": {"inner_key2": "value2"}
        }
        return dict_to_return = {
            "key1": {"inner_key1": "value1", "inner_key2": "value2"},
            "key2": {"inner_key3": "value3"}
        }
        '''
        dict_to_return = copy.deepcopy(dict_to_update)

        def deep_merge(dict_to_iterate, dict_to_update):
            for key, value in dict_to_iterate.items():
                if isinstance(value, dict):
                    node = dict_to_update.setdefault(key, {})
                    deep_merge(value, node)
                else:
                    dict_to_update[key] = value
            return dict_to_update
        return deep_merge(dict_to_iterate, dict_to_return)

    def list_to_deep_merged_dict(self, list_to_dict):
        '''
        Deep merge dicts of list items and return dict. For example:
        input list_to_dict = [
            {"key1": {"inner_key1": "value1"}},
            {"key1": {"inner_key2": "value2"}},
            {"key2": {"inner_key3": "value3"}}
        ]
        return dict_to_return = {
            "key1": {"inner_key1": "value1", "inner_key2": "value2"},
            "key2": {"inner_key3": "value3"}
        }
        '''
        dict_to_return = {}
        if list_to_dict is not None:
            for outer_item in list_to_dict:
                if isinstance(outer_item, dict):
                    dict_to_return = self.deep_merge_dict(outer_item, dict_to_return)
        return dict_to_return

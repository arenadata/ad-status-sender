import yaml

with open('/packages.list', 'r') as f:
    data = f.readlines()
packages = []
versions = []
for line in data:
    if 'Package:' in line:
        packages.append(line.split(':')[1].strip())
    if 'Version:' in line:
        versions.append(line.split(':')[1].strip().split('-')[0])
result = [{'name': name, 'version': version} for name, version in zip(packages, versions)]
print(yaml.dump(result))

import requests
import yaml
import gzip
import argparse
import logging
import xml.etree.ElementTree as ET

REPOMD_PREFIX = '{http://linux.duke.edu/metadata/repo}'
FILELIST_PREFIX = '{http://linux.duke.edu/metadata/filelists}'


def repotag(key):
    '''
    str: Construct specific to repomd.xml tag
    Args:
        key (str): key to search for
    '''

    tag = REPOMD_PREFIX + key
    logging.debug(f'repomd tag: {tag}')
    return tag


def filetag(key):
    '''
    str: Construct specific to filelists.xml tag
    Args:
        key (str): key to search for
    '''
    tag = FILELIST_PREFIX + key
    logging.debug(f'filelists tag: {tag}')
    return tag


def format_url(url):
    '''
    str: add trailing slash to url if absent
    Args:
        url (str): Yum repo baseurl
    '''
    logging.debug(f'Got URL: {url}')
    if url[-1] != '/':
        url += '/'
    logging.debug(f'Converted URL: {url}')
    return url


def xml_from_repomd(url):
    '''
    obj: XML Element representation of repomd.xml
    Args:
        url (str): Yum repo baseurl
    '''
    url = format_url(url) + 'repodata/repomd.xml'
    logging.info(f'Fetching {url}')
    res = requests.get(url)
    if res.status_code == 200:
        repomd = res.text
        return ET.fromstring(repomd)
    logging.error(f'Error fetching {url}: HTTP Code: {res.status_code}')


def xml_from_filelist(url, filelist):
    '''
    obj: XML Element representation of filelists.xml
    Args:
        url (str): Yum repo baseurl
        filelist (str): path to filelists.xml.gz
    '''
    url = format_url(url) + filelist
    logging.info(f'Fetching {url}')
    res = requests.get(url)
    if res.status_code == 200:
        compressed_object = res.content
        binary_object = gzip.decompress(compressed_object)
        return ET.fromstring(binary_object.decode())
    logging.error(f'Error fetching {url}: HTTP Code: {res.status_code}')


def get_filelist(repomd_xml):
    '''
    list: List of filelists.xml.gz files extracted from repomd XML object
    Args:
        repomd_xml (obj): XML Element representation of repomd.xml
    '''
    filelist = []
    for child in repomd_xml.findall(repotag('data')):
        if child.attrib.get('type') == 'filelists':
            for element in child.findall(repotag('location')):
                filelist.append(element.attrib.get('href'))
    logging.debug(f'Filelists: {filelist}')
    return filelist


def packages_list(filelist_xml):
    '''
    list: List of dicts {'name': package_name, 'version': package_version}
    Args:
        filelist_xml (obj): XML Element representation of filelists.xml
    '''
    pkg_list = []
    for child in filelist_xml.findall(filetag('package')):
        for element in child.findall(filetag('version')):
            pkg_list.append({'name': child.attrib.get('name'),
                             'version': element.attrib.get('ver')})
    if level == logging.DEBUG:
        for item in pkg_list:
            logging.debug(f'{item["name"]}: {item["version"]}')
    return pkg_list


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('url', help='URL of Yum repository (baseurl)')
    parser.add_argument('file', help='YAML file to output packages list')
    parser.add_argument('-v', '--verbose', help='Enable verbose logging',
                        action='store_true')
    args = parser.parse_args()
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(format='%(levelname)s:%(message)s', level=level)
    repomd_xml = xml_from_repomd(args.url)
    filelists = get_filelist(repomd_xml)
    packages = []
    for filelist in filelists:
        filelist_xml = xml_from_filelist(args.url, filelist)
        packages += packages_list(filelist_xml)
    logging.info(f'Writing to {args.file}')
    with open(args.file, 'w') as f:
        f.write(yaml.dump(packages))

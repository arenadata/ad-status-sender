This file is intended for submodule developers.
If you are not developing this submodule, please refer to the [README.md](README.md) file
---

##### Input vars

| Variable | Default | Description |
|----------|---------|-------------|
|adpg_run_sql_db_name|postgres|Name of DB for query.|
|adpg_run_sql_title|'Result SQL query'|Title of result|
|adpg_run_sql_query||SQL query. Example "select 1;"|
|adpg_run_sql_query_file||Path to file with SQL instructions.<br>Example: ~/{{ config_dir }}/migrate_db_files_history_to_partition.sql"|
|adpg_run_sql_quiet_mode|false|Disable show notify in adcm_check. Bool.|
|adpg_run_sql_options|"-At"|Options for psql|
|adpg_run_sql_system_user|postgres|System user who runs psql.|
|adpg_run_sql_delegate_to_host||Host who runs psql.|
|adpg_run_sql_cmd|"{{ adpg_path }}/bin/psql"|CMD for exec psql.|
|adpg_run_sql_chdir|"{{ adpg_datadir }}"|PATH, where to execute SQL query.|
|adpg_run_sql_port||Port on which postgres is running<br>(For example if psql goes to external ADPG).<br>Optional, if not set, than it will be got automatically from postgres PID|
|adpg_run_sql_env|LANG: "{{ environment_LANG }}"|Additional environment variables.|
|adpg_skip_validation|false|If true skip validation for force reconfigure ADPG.|
|adpg_common_use_adcm_check|false|Use adcm_check module.|

##### Output vars
```
adpg_run_sql_result: {
     rc,
     stdout,
     stderr,
     stdout_lines
}
```

> CAUTION! Do not quote db name,  it's already quoting in this role!

##### Usage examples

Including in submodule tasks:

```
- name: Validate pg_hba.conf
  include_tasks: "run_sql.yaml"
  vars:
    adpg_run_sql_query: "select line_number, error from pg_hba_file_rules where error is not null;"
  tags: always
```

Including as role in other roles:

```
- name: Check whether role pgbouncer already exist
  include_role:
    name: adpg_common
  vars:
    adpg_common_actions:
      - run_sql
    adpg_run_sql_query: SELECT 1 FROM pg_roles WHERE rolname='pgbouncer'
    adpg_run_sql_quiet_mode: true
  tags: always
```
